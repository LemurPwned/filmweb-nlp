import spacy 
from collections import defaultdict
from flask import request


nlp = spacy.load("en")


def main():
    try:
        myHeader = request.headers['x-my-header']
        body = request.get_json()
        print(f"body is {body}")
    except KeyError:
        return "Header 'x-my-header' not found"
    return "The header's value is '%s'" % myHeader


def map_filename(filenames):
    entities = defaultdict(list)
    for filename in filenames:
        with open(filename, 'r') as f:
            text = f.read()

        doc = nlp(text)
        for ent in doc.ents:
            if ent.text.replace(" ", "").replace("\n", "").strip() != "":
                # print(ent.label_, f"the text: {ent.text} of ent")   
                entities[ent.label_].append(ent.text)
    return entities


if __name__ == "__main__":
    d = map_filename(['text_files/random_text.txt'])
    print(d)